import pandas as pd
import numpy as np
from typing import List, Dict, Any, Tuple
import datetime
from sklearn.ensemble import IsolationForest
from src.core.history.storage.models import Event
from src.utils.logger import setup_logger

logger = setup_logger("event_detector")

def decompose_monthly_series(series: pd.Series, period: int = 3) -> Tuple[pd.Series, pd.Series, pd.Series]:
    """
    Decomposes a monthly time series into Trend, Seasonality, and Residual components.
    Resilient to short time series.
    """
    n = len(series)
    if n < 6:
        # Too short: return simple detrended series as residual
        trend = series.rolling(window=max(1, n//2), min_periods=1, center=True).mean()
        residual = series - trend
        seasonality = pd.Series(0.0, index=series.index)
        return trend, seasonality, residual
        
    try:
        from statsmodels.tsa.seasonal import seasonal_decompose
        # Use a short period to accommodate limited monthly data points
        decomp = seasonal_decompose(series, period=period, extrapolate_trend='freq')
        return decomp.trend, decomp.seasonal, decomp.resid
    except Exception as e:
        logger.debug(f"statsmodels decomposition failed: {e}. Using fallback decomposition.")
        # Fallback rolling median-based decomposition
        trend = series.rolling(window=3, min_periods=1, center=True).median()
        detrended = series - trend
        # Compute seasonal index
        seasonal_idx = detrended.groupby(detrended.index % period).transform('mean')
        residual = detrended - seasonal_idx
        return trend, seasonal_idx, residual

def calculate_modified_z_scores(residual: pd.Series) -> pd.Series:
    """
    Calculates robust modified Z-scores on the residual series using Median Absolute Deviation (MAD).
    """
    median = residual.median()
    abs_deviation = (residual - median).abs()
    mad = abs_deviation.median()
    if mad == 0:
        # Fallback to standard deviation if MAD is 0
        std = residual.std()
        if std == 0 or pd.isna(std):
            return pd.Series(0.0, index=residual.index)
        return (residual - residual.mean()) / std
    return 0.6745 * (residual - median) / mad


class EventDetector:
    def __init__(self, lookback_window: int = 3):
        self.lookback_window = lookback_window

    def detect_events(self, df_hist: pd.DataFrame) -> List[Event]:
        """
        Groups the historical timeline data by product and month,
        performs STL decomposition, and runs MAD and Isolation Forest outlier detection.
        """
        events = []
        df = df_hist.copy()
        df["date"] = pd.to_datetime(df["date"])
        
        # Extract YYYY-MM period for monthly aggregation
        df["year_month"] = df["date"].dt.to_period("M")
        
        # Define monthly aggregation rules
        agg_rules = {
            "revenue": "sum",
            "profit": "sum",
            "orders": "sum",
            "marketing_spend": "sum",
            "traffic": "sum",
            "conversion_rate": "mean",
            "retention_rate": "mean",
            "avg_selling_price": "mean",
            "discount_pct": "mean",
            "shipping_fee": "mean",
            "current_roas": "mean",
            "inventory_available": "last",
            "brand": "first",
            "category": "first"
        }
        
        logger.info(f"Aggregating daily timeline records to monthly granularity...")
        
        # Group by product_id and year_month
        monthly_data = []
        for (product_id, ym), group in df.groupby(["product_id", "year_month"]):
            row_dict = {
                "product_id": product_id,
                "date": ym.to_timestamp()  # Represents the first day of the month
            }
            for col, rule in agg_rules.items():
                if col in group.columns:
                    if rule == "sum":
                        row_dict[col] = float(group[col].sum())
                    elif rule == "mean":
                        row_dict[col] = float(group[col].mean())
                    elif rule == "last":
                        row_dict[col] = float(group[col].iloc[-1])
                    elif rule == "first":
                        row_dict[col] = group[col].iloc[0]
            monthly_data.append(row_dict)
            
        df_monthly = pd.DataFrame(monthly_data)
        df_monthly = df_monthly.sort_values(by=["product_id", "date"]).reset_index(drop=True)
        
        products = df_monthly["product_id"].unique()
        logger.info(f"Running STL Decomposition and Multivariate Isolation Forest outlier checks on {len(products)} products...")
        
        # Check anomalies per product group
        for product_id, group in df_monthly.groupby("product_id"):
            group = group.sort_values(by="date").reset_index(drop=True)
            if len(group) < self.lookback_window + 3:
                logger.debug(f"Product {product_id} has insufficient months ({len(group)}) for STL analysis. Skipping.")
                continue
                
            # 1. Run STL Decomposition & Compute MAD Modified Z-Scores
            rolling_cols = [
                "revenue", "profit", "orders", "marketing_spend", "traffic",
                "conversion_rate", "retention_rate", "avg_selling_price",
                "discount_pct", "shipping_fee", "current_roas"
            ]
            
            z_scores_df = pd.DataFrame(index=group.index)
            for col in rolling_cols:
                trend, seasonal, resid = decompose_monthly_series(group[col])
                # Shift by 1 to prevent target data leakage
                shifted_resid = resid.shift(1)
                z_scores_df[col] = calculate_modified_z_scores(shifted_resid)
                
            # 2. Run Isolation Forest for Multivariate Operational Anomaly Detection
            features = ["inventory_available", "orders", "shipping_fee"]
            X = group[features].fillna(0).values
            iso_anomalies = np.zeros(len(group))
            
            if len(group) >= 6:
                try:
                    clf = IsolationForest(contamination=0.15, random_state=42)
                    preds = clf.fit_predict(X)
                    # -1 indicates anomaly, map to 1 for easier condition checks
                    iso_anomalies = np.where(preds == -1, 1, 0)
                except Exception as e:
                    logger.debug(f"Isolation Forest failed for product {product_id}: {e}")
            
            # Iterate through evaluation months
            for i in range(self.lookback_window, len(group)):
                row = group.iloc[i]
                date_val = row["date"].date()
                
                # Fetch robust modified Z-scores
                z_disc = z_scores_df["discount_pct"].iloc[i]
                z_prof = z_scores_df["profit"].iloc[i]
                z_ship = z_scores_df["shipping_fee"].iloc[i]
                z_traf = z_scores_df["traffic"].iloc[i]
                z_cvr = z_scores_df["conversion_rate"].iloc[i]
                z_ret = z_scores_df["retention_rate"].iloc[i]
                z_spend = z_scores_df["marketing_spend"].iloc[i]
                z_roas = z_scores_df["current_roas"].iloc[i]
                z_rev = z_scores_df["revenue"].iloc[i]
                
                # ----------------------------------------------------
                # Advanced Anomaly Rules by Business Pillars
                # ----------------------------------------------------
                
                # Pillar 1: Profitability & Margins
                # 1.1 Margin Cannibalization (Discount spikes, Profit collapses)
                if z_disc > 1.5 and z_prof < -1.0:
                    events.append(self._create_event(
                        date_val, product_id, "Margin Cannibalization", "High", "profit, discount_pct",
                        f"Discount rate spiked (Modified Z-score: {z_disc:.2f}) but profitability dropped (Modified Z-score: {z_prof:.2f})",
                        "Elevated discount rates failed to drive incremental margin volume, diluting net profit margins.",
                        abs(z_prof)
                    ))
                # 1.2 Shipping Drag
                if z_ship > 1.5 and z_prof < -1.0:
                    events.append(self._create_event(
                        date_val, product_id, "Shipping Cost Drag", "Medium", "profit, shipping_fee",
                        f"Shipping charges increased (Modified Z-score: {z_ship:.2f}) while profit fell (Modified Z-score: {z_prof:.2f})",
                        "Elevated transit/fulfillment charges compressed monthly product margin yields.",
                        abs(z_prof)
                    ))
                    
                # Pillar 2: Conversion & Retention Leakage
                # 2.1 Conversion Leakage
                if z_traf > 1.5 and z_cvr < -1.5:
                    events.append(self._create_event(
                        date_val, product_id, "Conversion Leakage", "High", "traffic, conversion_rate",
                        f"Traffic surged (Modified Z-score: {z_traf:.2f}) but conversion rate collapsed (Modified Z-score: {z_cvr:.2f})",
                        "Store traffic failed to monetize effectively. Suggests landing page bugs, check-out errors, or low-quality traffic sources.",
                        abs(z_cvr)
                    ))
                # 2.2 Customer Retention Decay
                if z_ret < -1.8 or row["retention_rate"] < 0.65:
                    events.append(self._create_event(
                        date_val, product_id, "Loyalty Decay", "Medium", "retention_rate",
                        f"Monthly retention rate collapsed to {row['retention_rate']*100:.2f}% (Modified Z-score: {z_ret:.2f})",
                        "Erosion of repeat purchase behavior, decreasing long-term customer lifetime value.",
                        abs(z_ret) if not pd.isna(z_ret) else 1.5
                    ))
                    
                # Pillar 3: Marketing Capital Inefficiency
                # 3.1 ROAS Bleed
                if z_spend > 1.5 and (row["current_roas"] < 1.2 or z_roas < -1.5):
                    events.append(self._create_event(
                        date_val, product_id, "ROAS Bleed", "High", "marketing_spend, current_roas",
                        f"Ad budget expanded (Modified Z-score: {z_spend:.2f}) but ROAS dropped to {row['current_roas']:.2f}",
                        "Inefficient ad campaigns. Budget allocation is outstripping sales return rates, driving negative ROI.",
                        abs(z_roas) if not pd.isna(z_roas) else 1.5
                    ))
                    
                # Pillar 4: Operational & Supply Risk
                # 4.1 Days of Stock (DOS) Warning
                monthly_orders = max(1.0, row["orders"])
                dos = row["inventory_available"] / (monthly_orders / 30.0)
                if dos < 7.0:
                    events.append(self._create_event(
                        date_val, product_id, "Inventory Risk", "Critical", "inventory",
                        f"Days of Stock (DOS) dropped to a critical {dos:.1f} days (inventory: {int(row['inventory_available'])} units left)",
                        "High risk of immediate stockout based on monthly order velocities.",
                        2.0
                    ))
                    
                # 4.2 Isolation Forest Multivariate Operational Outlier
                if iso_anomalies[i] == 1 and dos < 14.0:
                    events.append(self._create_event(
                        date_val, product_id, "Multivariate Operational Anomaly", "Medium", "inventory, orders, shipping_fee",
                        f"Isolation Forest flagged a joint anomaly on stock ({int(row['inventory_available'])} units) and shipping fee (${row['shipping_fee']:.2f})",
                        "Co-variance outlier detected across supply and fulfillment channels.",
                        1.5
                    ))
                    
                # Pillar 5: General Monthly Outlier Checks (Revenue Spikes and Drops)
                if z_rev >= 2.0:
                    events.append(self._create_event(
                        date_val, product_id, "Revenue Spike", "High", "revenue",
                        f"Monthly revenue jumped to ${row['revenue']:,.2f} (Modified Z-score: {z_rev:.2f})",
                        "Exceeded historical baseline performance bounds.",
                        z_rev
                    ))
                elif z_rev <= -2.0:
                    events.append(self._create_event(
                        date_val, product_id, "Revenue Drop", "Critical", "revenue",
                        f"Monthly revenue dropped to ${row['revenue']:,.2f} (Modified Z-score: {z_rev:.2f})",
                        "Fell significantly below historical baseline performance bounds.",
                        abs(z_rev)
                    ))
                            
        # Sort events chronologically
        events = sorted(events, key=lambda x: x.event_date)
        logger.info(f"Anomaly detection complete. Total events detected: {len(events)}")
        return events

    def _create_event(self, date_val: datetime.date, product_id: str, event_type: str, 
                      severity: str, kpis: str, reason: str, impact: str, score: float) -> Event:
        # Normalize score to confidence between 0.5 and 1.0
        confidence = min(1.0, max(0.5, 0.5 + (score / 10.0)))
        logger.info(
            f"Detected Outlier Event for product {product_id} on {date_val.strftime('%Y-%m')}: "
            f"[{event_type} - {severity}] Reason: {reason} | Impact: {impact}"
        )
        return Event(
            event_date=date_val,
            product_id=product_id,
            event_type=event_type,
            severity=severity,
            kpis_affected=kpis,
            reason=reason,
            business_impact=impact,
            confidence=round(float(confidence), 2)
        )

