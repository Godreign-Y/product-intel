import pandas as pd
import numpy as np
from typing import List, Dict, Any, Tuple
import datetime
from scipy import stats
from sklearn.linear_model import LinearRegression
import statsmodels.api as sm
from src.core.history.storage.models import Experiment
from src.utils.logger import setup_logger

logger = setup_logger("experiment_detector")

def pelt_change_point_detection(signal: np.ndarray, penalty: float = 4.0) -> List[int]:
    """
    PELT (Pruned Exact Linear Time) change point detection using the ruptures library
    with a robust fallback to a native dynamic-programming implementation.
    """
    n = len(signal)
    if n < 6:
        return []
    try:
        import ruptures as rpt
        # Use l2 cost model to find shift in mean/variance
        algo = rpt.Pelt(model="l2").fit(signal)
        # predict returns index of first element of new segment, ending with length of signal
        change_points = algo.predict(pen=penalty)
        if change_points and change_points[-1] == n:
            change_points = change_points[:-1]
        return sorted([int(cp) for cp in change_points if cp > 0])
    except Exception as e:
        logger.warning(f"Ruptures PELT execution failed: {e}. Falling back to native dynamic programming PELT.")
        return native_pelt_change_point_detection(signal, penalty)

def native_pelt_change_point_detection(signal: np.ndarray, penalty: float = 4.0) -> List[int]:
    """
    Native fallback implementation of PELT (Pruned Exact Linear Time) change point detection.
    Finds change points in mean/variance of 1D signal.
    """
    n = len(signal)
    if n < 6:
        return []
        
    sums = np.cumsum(np.insert(signal, 0, 0.0))
    sq_sums = np.cumsum(np.insert(signal**2, 0, 0.0))
    
    def get_cost(a: int, b: int) -> float:
        if a >= b:
            return 0.0
        length = b - a
        s = sums[b] - sums[a]
        sq_s = sq_sums[b] - sq_sums[a]
        variance = (sq_s / length) - (s / length)**2
        return length * max(0.0, variance)

    F = np.zeros(n + 1)
    R = [0]
    cp = np.zeros(n + 1, dtype=int)
    F[0] = -penalty
    
    for t in range(1, n + 1):
        min_val = float('inf')
        best_tau = 0
        for tau in R:
            val = F[tau] + get_cost(tau, t) + penalty
            if val < min_val:
                min_val = val
                best_tau = tau
        F[t] = min_val
        cp[t] = best_tau
        
        new_R = [tau for tau in R if F[tau] + get_cost(tau, t) < F[t] + penalty]
        new_R.append(t)
        R = new_R

    change_points = []
    curr = n
    while curr > 0:
        prev = cp[curr]
        if prev > 0:
            change_points.append(prev)
        curr = prev
        
    return sorted(change_points)

def cusum_change_point_detection(signal: np.ndarray, threshold: float = 4.0, drift: float = 0.6) -> List[int]:
    """
    Lightweight CUSUM (Cumulative Sum) fallback change point detection.
    """
    n = len(signal)
    if n < 4:
        return []
    mean = np.mean(signal)
    std = np.std(signal)
    if std == 0:
        return []
    
    norm_sig = (signal - mean) / std
    g_pos = 0.0
    g_neg = 0.0
    
    change_points = []
    for i in range(n):
        val = norm_sig[i]
        g_pos = max(0.0, g_pos + val - drift)
        g_neg = max(0.0, g_neg - val - drift)
        if g_pos > threshold or g_neg > threshold:
            change_points.append(i)
            g_pos = 0.0
            g_neg = 0.0
    return change_points


class ExperimentDetector:
    def __init__(self, window_days: int = 14, min_duration: int = 7):
        self.window_days = window_days
        self.min_duration = min_duration

    def infer_experiments(self, df_hist: pd.DataFrame) -> List[Experiment]:
        """
        Scans driver metrics in time-series data using PELT/CUSUM to detect breakpoints,
        and runs Interrupted Time Series (ITS) OLS regression for causal lift estimation.
        """
        experiments = []
        df = df_hist.copy()
        df["date"] = pd.to_datetime(df["date"])
        df = df.sort_values(by=["product_id", "date"]).reset_index(drop=True)
        
        # Drivers to monitor and their thresholds (relative or absolute)
        drivers = {
            "avg_selling_price": {"type": "rel", "threshold": 0.05, "name": "Pricing Experiment"},
            "discount_pct": {"type": "abs", "threshold": 5.0, "name": "Discount Experiment"},
            "marketing_spend": {"type": "rel", "threshold": 0.30, "name": "Marketing Spend Experiment"},
            "shipping_fee": {"type": "abs", "threshold": 5.0, "name": "Shipping Fee Experiment"}
        }
        
        products = df["product_id"].unique()
        logger.info(f"Scanning driver metrics using PELT and CUSUM on {len(products)} products...")
        
        for product_id, group in df.groupby("product_id"):
            group = group.sort_values(by="date").reset_index(drop=True)
            n_len = len(group)
            if n_len < (self.window_days * 2) + self.min_duration:
                continue
                
            brand = group["brand"].iloc[0] if "brand" in group.columns else "Generic"
            category = group["category"].iloc[0] if "category" in group.columns else "Generic"
            
            for col, config in drivers.items():
                col_type = config["type"]
                thresh = config["threshold"]
                exp_name = config["name"]
                
                signal = group[col].fillna(0).values
                
                # 1. Run PELT Change Point Detection (Fallback to CUSUM)
                change_points = pelt_change_point_detection(signal, penalty=4.0)
                if not change_points:
                    change_points = cusum_change_point_detection(signal, threshold=4.0, drift=0.6)
                
                # Evaluate detected change point candidates
                for idx in change_points:
                    if idx < self.window_days or idx > n_len - self.window_days:
                        continue
                        
                    date_val = group.iloc[idx]["date"].date()
                    
                    before_slice = group.iloc[idx - self.window_days : idx]
                    after_slice = group.iloc[idx : idx + self.window_days]
                    
                    before_mean = before_slice[col].mean()
                    after_mean = after_slice[col].mean()
                    
                    is_step_change = False
                    if col_type == "rel":
                        if before_mean > 0:
                            diff_pct = abs(after_mean - before_mean) / before_mean
                            is_step_change = diff_pct >= thresh
                        elif after_mean > 0:
                            is_step_change = True
                    else:
                        is_step_change = abs(after_mean - before_mean) >= thresh
                        
                    if is_step_change:
                        start_date = date_val
                        end_date = group.iloc[min(n_len - 1, idx + self.window_days - 1)]["date"].date()
                        
                        logger.info(
                            f"Experiment detected for product {product_id} on driver '{col}' at {start_date}: "
                            f"before={before_mean:.2f}, after={after_mean:.2f}. Fitting ITS model..."
                        )
                        
                        # Pre and Post KPI Means
                        kpis = ["revenue", "profit", "orders", "conversion_rate", "retention_rate"]
                        before_metrics = {}
                        after_metrics = {}
                        
                        for kpi in kpis:
                            before_metrics[kpi] = round(float(before_slice[kpi].mean()), 4)
                            after_metrics[kpi] = round(float(after_slice[kpi].mean()), 4)
                            
                        # Determine Primary KPI
                        primary_kpi = "conversion_rate"
                        if col == "avg_selling_price" or col == "marketing_spend":
                            primary_kpi = "revenue"
                        elif col == "discount_pct":
                            primary_kpi = "profit"
                            
                        # 2. Interrupted Time Series with Counterfactual Projections
                        pre_len = len(before_slice)
                        post_len = len(after_slice)
                        
                        # Pre-trend linear regression
                        X_pre = np.arange(pre_len).reshape(-1, 1)
                        y_pre = before_slice[primary_kpi].fillna(0).values
                        
                        model_pre = LinearRegression()
                        model_pre.fit(X_pre, y_pre)
                        
                        # Predict Counterfactual Baseline
                        X_post = (np.arange(post_len) + pre_len).reshape(-1, 1)
                        counterfactual = model_pre.predict(X_post)
                        
                        # Summaries
                        expected_kpi = float(np.mean(counterfactual))
                        observed_kpi = float(np.mean(after_slice[primary_kpi].values))
                        
                        absolute_lift = observed_kpi - expected_kpi
                        relative_lift_pct = (absolute_lift / expected_kpi * 100.0) if expected_kpi > 0 else 0.0
                        
                        # Save causal metrics inside JSON column
                        after_metrics["expected_counterfactual"] = round(expected_kpi, 4)
                        after_metrics["observed_actual"] = round(observed_kpi, 4)
                        after_metrics["causal_lift_pct"] = round(relative_lift_pct, 2)
                        
                        # 3. Fit full ITS Regression for p-value Estimation
                        total_len = pre_len + post_len
                        t_var = np.arange(total_len)
                        intervention_var = np.array([0] * pre_len + [1] * post_len)
                        time_post_var = np.array([0] * pre_len + list(range(1, post_len + 1)))
                        
                        X_its = np.column_stack((t_var, intervention_var, time_post_var))
                        y_its = np.concatenate((before_slice[primary_kpi].fillna(0).values, after_slice[primary_kpi].fillna(0).values))
                        
                        try:
                            X_its_const = sm.add_constant(X_its, has_constant='add')
                            model_its = sm.OLS(y_its, X_its_const).fit()
                            p_val = float(model_its.pvalues[2]) if len(model_its.pvalues) > 2 else 0.5
                        except Exception as e:
                            logger.warning(f"ITS Regression fit failed: {e}. Falling back to Welch t-test.")
                            # Fallback to standard t-test
                            t_stat, p_val = stats.ttest_ind(
                                before_slice[primary_kpi].values,
                                after_slice[primary_kpi].values,
                                equal_var=False
                            )
                            
                        if pd.isna(p_val):
                            p_val = 0.5
                            
                        # Confidence Score based on p-value
                        confidence = 1.0 - p_val
                        confidence = min(0.99, max(0.50, confidence))
                        
                        if p_val < 0.10:
                            if absolute_lift > 0:
                                outcome = "positive"
                            else:
                                outcome = "negative"
                        else:
                            outcome = "neutral"
                            
                        exp_id = f"EXP_{col[:3].upper()}_{product_id}_{start_date.strftime('%m%d')}"
                        change_direction = "increased" if after_mean > before_mean else "decreased"
                        change_summary = (
                            f"Driver '{col}' was {change_direction} from an average of "
                            f"{before_mean:.2f} to {after_mean:.2f} starting on {start_date.strftime('%Y-%m-%d')}."
                        )
                        
                        logger.info(
                            f"ITS results: {exp_id}. Expected {primary_kpi}={expected_kpi:.4f}, "
                            f"Observed={observed_kpi:.4f}, Lift={relative_lift_pct:+.2f}%, p-val={p_val:.4f}"
                        )
                        
                        # Determine season based on start_date
                        season_val = "Winter" if start_date.month in (12, 1, 2) else "Spring" if start_date.month in (3, 4, 5) else "Summer" if start_date.month in (6, 7, 8) else "Fall"

                        exp_instance = Experiment(
                            experiment_id=exp_id,
                            type=exp_name,
                            product_ids=product_id,
                            category=category,
                            brand=brand,
                            start_date=start_date,
                            end_date=end_date,
                            before_metrics=before_metrics,
                            after_metrics=after_metrics,
                            change_summary=change_summary,
                            improvement_pct=round(float(relative_lift_pct), 2),  # Causal lift is the primary improvement metric
                            outcome=outcome,
                            confidence_score=round(float(confidence), 2),
                            driver=col,
                            segment=category,
                            season=season_val,
                            outcome_score=round(float(relative_lift_pct), 2),
                            confidence=round(float(confidence), 2)
                        )
                        experiments.append(exp_instance)
                        
        seen_ids = set()
        unique_experiments = []
        for exp in experiments:
            if exp.experiment_id not in seen_ids:
                seen_ids.add(exp.experiment_id)
                unique_experiments.append(exp)
                
        logger.info(f"Experiment inference complete. Total inferred: {len(unique_experiments)}")
        return unique_experiments
