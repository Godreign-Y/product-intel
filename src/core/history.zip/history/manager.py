import pandas as pd
import datetime
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Optional

from src.core.history.storage.database import engine, Base
from src.core.history.storage.models import Snapshot, Event, Experiment, Report, ReportEmbedding, KnowledgeBase
from src.core.decision.storage.models import DecisionContext, Hypothesis, ValidationResult, ConfidenceScore, Recommendation, ExperimentPlan
from src.core.history.builders.snapshot import SnapshotBuilder
from src.core.history.detectors.event import EventDetector
from src.core.history.detectors.experiment import ExperimentDetector
from src.core.history.reports.generator import ReportGenerator
from src.core.history.embeddings.encoder import SentenceTransformerEncoder
from src.core.history.retrievers.similarity import SimilarityRetriever
from src.utils.logger import setup_logger

logger = setup_logger("history_manager")

class HistoryManager:
    def __init__(self, db: Session, encoder: Optional[SentenceTransformerEncoder] = None):
        self.db = db
        self.encoder = encoder or SentenceTransformerEncoder()
        self.retriever = SimilarityRetriever(db, self.encoder)
        self.snapshot_builder = SnapshotBuilder()
        self.event_detector = EventDetector()
        self.experiment_detector = ExperimentDetector()
        self.report_generator = ReportGenerator()

    def rebuild_tables(self):
        """
        Cleans and recreates the historical intelligence repository tables
        without dropping the raw product_performance dataset.
        """
        from src.core.history.storage.models import Snapshot, Event, Experiment, Report, ReportEmbedding, KnowledgeBase
        
        logger.info("Dropping historical repository tables selectively...")
        tables = [
            ReportEmbedding.__table__,
            Report.__table__,
            Experiment.__table__,
            Event.__table__,
            Snapshot.__table__,
            KnowledgeBase.__table__
        ]
        for table in tables:
            table.drop(bind=engine, checkfirst=True)
            
        logger.info("Creating historical repository tables selectively...")
        for table in reversed(tables):
            table.create(bind=engine, checkfirst=True)
            
        logger.info("Database tables initialized successfully.")

    def run_build_pipeline(self, df_hist: pd.DataFrame, force_rebuild: bool = False) -> Dict[str, Any]:
        """
        Runs the complete history build pipeline:
        1. Aggregates snapshots.
        2. Scans events.
        3. Scans experiments.
        4. Synthesizes reports and computes vector embeddings.
        """
        logger.info("Initializing Historical Intelligence build pipeline...")
        if force_rebuild:
            logger.info("Force rebuild requested. Selective drop and recreate of tables...")
            self.rebuild_tables()
        else:
            logger.info("Incremental build requested. Creating missing tables (if any) checkfirst...")
            Base.metadata.create_all(bind=engine)
            
        df = df_hist.copy()
        df["date"] = pd.to_datetime(df["date"])
        df = df.sort_values(by="date").reset_index(drop=True)
        
        # 1. Build Snapshots
        logger.info("Step 1: Building daily snapshots...")
        unique_dates = sorted(df["date"].unique())
        
        prev_revenues = {}
        snapshots_created = 0
        snapshots_updated = 0
        
        for d_timestamp in unique_dates:
            d_val = pd.to_datetime(d_timestamp).date()
            df_date = df[df["date"] == d_timestamp]
            
            # Check if snapshot already exists
            existing_snap = self.db.query(Snapshot).filter(Snapshot.snapshot_date == d_val).first()
            
            if existing_snap:
                logger.debug(f"Snapshot already exists for {d_val}. Updating fields...")
                new_snap = self.snapshot_builder.build_snapshot(df_date, d_val, prev_revenues)
                for col in Snapshot.__table__.columns.keys():
                    if col != 'id':
                        setattr(existing_snap, col, getattr(new_snap, col))
                snapshots_updated += 1
            else:
                snap = self.snapshot_builder.build_snapshot(df_date, d_val, prev_revenues)
                self.db.add(snap)
                snapshots_created += 1
            
            # Save product revenues for the next day's growth calculation
            prev_revenues = df_date.groupby("product_id")["revenue"].sum().to_dict()
            
        self.db.commit()
        logger.info(f"Daily snapshots processed: created={snapshots_created}, updated={snapshots_updated}")
        
        # 2. Build Events
        logger.info("Step 2: Executing Event Outlier Scan...")
        detected_events = self.event_detector.detect_events(df)
        events_created = 0
        events_updated = 0
        
        for ev in detected_events:
            existing_ev = self.db.query(Event).filter(
                Event.event_date == ev.event_date,
                Event.product_id == ev.product_id,
                Event.event_type == ev.event_type
            ).first()
            
            if existing_ev:
                logger.debug(f"Event already exists for product {ev.product_id} on {ev.event_date}: {ev.event_type}. Updating...")
                for col in Event.__table__.columns.keys():
                    if col != 'id':
                        setattr(existing_ev, col, getattr(ev, col))
                events_updated += 1
            else:
                self.db.add(ev)
                events_created += 1
            
        self.db.commit()
        logger.info(f"Events outlier scan processed: created={events_created}, updated={events_updated}")
        
        # 3. Build Experiments
        logger.info("Step 3: Executing Experiment Step-Change Scan...")
        inferred_exps = self.experiment_detector.infer_experiments(df)
        
        # Cap to top 30 most significant experiments by absolute impact and confidence
        inferred_exps = sorted(inferred_exps, key=lambda x: abs(x.improvement_pct) * x.confidence_score, reverse=True)[:30]
        
        experiments_created = 0
        experiments_updated = 0
        reports_created = 0
        reports_updated = 0
        embeddings_created = 0
        
        logger.info(f"Filtered to top {len(inferred_exps)} most significant experiments. Processing reports and embeddings...")
        
        for idx, exp in enumerate(inferred_exps):
            existing_exp = self.db.query(Experiment).filter(
                Experiment.experiment_id == exp.experiment_id
            ).first()
            
            if existing_exp:
                logger.debug(f"Experiment {exp.experiment_id} already exists. Updating metrics...")
                for col in Experiment.__table__.columns.keys():
                    if col not in ['id', 'experiment_id']:
                        setattr(existing_exp, col, getattr(exp, col))
                db_exp = existing_exp
                experiments_updated += 1
            else:
                self.db.add(exp)
                self.db.commit()  # commit to get exp.id
                db_exp = exp
                experiments_created += 1
            
            # 4. Generate report (LLM or Fallback template)
            existing_report = self.db.query(Report).filter(
                Report.experiment_id == db_exp.id
            ).first()
            
            if existing_report:
                logger.debug(f"Report already exists for experiment {db_exp.experiment_id}. Re-using.")
                db_report = existing_report
            else:
                report = self.report_generator.generate_report(db_exp)
                report.experiment_id = db_exp.id
                self.db.add(report)
                self.db.commit()  # commit to get report.id
                db_report = report
                reports_created += 1
            
            # 5. Compute embedding and save
            existing_emb = self.db.query(ReportEmbedding).filter(
                ReportEmbedding.report_id == db_report.id
            ).first()
            
            if existing_emb:
                logger.debug(f"Embedding already exists for report of experiment {db_exp.experiment_id}. Skipping encode.")
            else:
                text_to_encode = f"{db_exp.type} {db_exp.change_summary} Learnings: {db_report.structured_json.get('learnings', '')} Recommendations: {db_report.structured_json.get('recommendations', '')}"
                emb_vector = self.encoder.encode(text_to_encode)
                
                emb = ReportEmbedding(
                    report_id=db_report.id,
                    embedding=emb_vector,
                    meta_data={
                        "experiment_id": db_exp.experiment_id,
                        "type": db_exp.type,
                        "category": db_exp.category,
                        "outcome": db_exp.outcome
                    }
                )
                self.db.add(emb)
                embeddings_created += 1
            
        self.db.commit()
        logger.info(
            f"Experiments build complete. "
            f"Experiments: created={experiments_created}, updated={experiments_updated} | "
            f"Reports: created={reports_created}, reused={len(inferred_exps) - reports_created} | "
            f"Embeddings: created={embeddings_created}"
        )
        
        return {
            "status": "success",
            "snapshots_created": snapshots_created,
            "snapshots_updated": snapshots_updated,
            "events_detected": events_created,
            "events_updated": events_updated,
            "experiments_inferred": experiments_created,
            "experiments_updated": experiments_updated,
            "reports_generated": reports_created,
            "embeddings_generated": embeddings_created
        }

    def semantic_search(self, query: str, limit: int = 5, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.retriever.semantic_search(query, limit, filters)

    def find_similar_experiments(self, category: str, features: Dict[str, Any], limit: int = 3) -> List[Dict[str, Any]]:
        return self.retriever.find_similar_experiments(category, features, limit)

    def extract_topic_insights(self, topic: str) -> Dict[str, Any]:
        return self.retriever.extract_topic_insights(topic)
